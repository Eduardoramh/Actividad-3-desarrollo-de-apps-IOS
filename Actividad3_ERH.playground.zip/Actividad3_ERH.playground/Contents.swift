import UIKit
//Punto 4
var numero: Int = 1
var numero2 = 2
var numero3: Int = 3
var numero4 = 4

var decimal: Float = 1.1
var deciaml2 = 2.2

var texto: String = "Hola"
var texto2 = "Como estas"

//Punto 5

var texto3 = "Esto es un ejemplo de"
let otro_texto3: String = "asociacion"

var numero5 = 5
let otro_numero5: Int = 6

//Punto 6

var Numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
var diasSemana = ["Lunes":1, "Martes": 2, "Miercoles":3, "Jueves":4, "Viernes":5, "Sabado": 6, "Domingo": 7]
